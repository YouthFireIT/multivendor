/*=========================================================================================
	File Name: documentation.js
	Description: Theme documentation js file
	----------------------------------------------------------------------------------------
	Item Name: Modern Admin - Clean Bootstrap 4 Dashboard HTML Template
	Author: PIXINVENT
	Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

$(document).ready(function(){
   $('body').scrollspy({ target: '#sidebar-page-navigation' });
});